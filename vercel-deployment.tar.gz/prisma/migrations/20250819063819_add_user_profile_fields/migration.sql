-- AlterTable
ALTER TABLE "users" ADD COLUMN "bio" TEXT;
ALTER TABLE "users" ADD COLUMN "country" TEXT;
ALTER TABLE "users" ADD COLUMN "experience" TEXT;
ALTER TABLE "users" ADD COLUMN "phoneNumber" TEXT;
