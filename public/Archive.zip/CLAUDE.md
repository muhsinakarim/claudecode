@AGENTS.md

# Alamy Design System 2.0

All UI work in this project MUST use the tokens and components defined below.
Never use raw hex values, Tailwind's built-in color names (slate, zinc, etc.),
or arbitrary font sizes in components. Always map to design-system tokens.

## Stack

- Next.js 16 (App Router), React 19, Tailwind CSS v4
- Tokens: `app/globals.css` (`@theme` block)
- Components: `components/ui/`
- Font: Noto Sans (via `next/font/google`); PP Formula Condensed (H1 only — requires local font file, see `app/layout.js`)

## Color tokens

Always use semantic tokens, not primitives.

| Token class              | Use for                               |
|--------------------------|---------------------------------------|
| `bg-surface-primary`     | Page / card backgrounds (light)       |
| `bg-surface-secondary`   | Subtle background, sidebars           |
| `bg-surface-invert`      | Full-black panels                     |
| `bg-surface-brand`       | CTA fills, active states              |
| `bg-surface-brand-minimal` | Light green tints                   |
| `text-text-primary`      | Main body copy                        |
| `text-text-secondary`    | Sub-labels, captions                  |
| `text-text-tertiary`     | Placeholders, disabled labels         |
| `text-text-invert`       | Text on dark surfaces                 |
| `text-text-brand`        | Brand-green text                      |
| `text-text-red`          | Destructive / error text              |
| `border-border-primary`  | Default border                        |
| `border-border-tertiary` | Subtle border                         |
| `border-border-brand`    | Brand-coloured border                 |
| `border-border-red`      | Error border                          |
| `text-icon-primary`      | Icons on light surface                |
| `text-icon-invert`       | Icons on dark surface                 |
| `text-icon-brand`        | Brand-coloured icons                  |

Dark mode is automatic via `@media (prefers-color-scheme: dark)`.
All semantic tokens remap their values — components do not need
explicit dark: variants if they use semantic tokens correctly.

For `onDark` components (rendered on a dark surface in light mode),
pass `onDark` prop. The component uses `text-text-invert`, `border-border-invert`, etc.

## Spacing

Use named spacing classes everywhere. Do NOT use Tailwind's numeric scale (`p-4`, `p-8`, etc.).

| Class    | Value |
|----------|-------|
| `p-none` | 0     |
| `p-xs`   | 4px   |
| `p-sm`   | 8px   |
| `p-md`   | 16px  |
| `p-lg`   | 24px  |
| `p-xl`   | 32px  |
| `p-2xl`  | 40px  |
| `p-3xl`  | 48px  |
| `p-4xl`  | 56px  |
| `p-5xl`  | 64px  |
| `p-6xl`  | 72px  |
| `p-7xl`  | 80px  |

Same names work for `m-*`, `gap-*`, `space-x-*`, `px-*`, `py-*`, etc.

## Border radius

| Class        | Value |
|--------------|-------|
| `rounded-none` | 0   |
| `rounded-xs`   | 4px |
| `rounded-sm`   | 8px |
| `rounded-md`   | 16px |
| `rounded-lg`   | 24px |
| `rounded-xl`   | 32px |

For fully circular elements (avatar, icon button) use `rounded-full`.

## Typography

| Role                | Font                  | Size class        | Weight |
|---------------------|-----------------------|-------------------|--------|
| H1                  | `font-display`        | `text-display`    | Bold   |
| H2                  | `font-sans`           | `text-h2`         | Bold   |
| H3                  | `font-sans`           | `text-h3`         | Bold   |
| H4                  | `font-sans`           | `text-h4`         | Bold   |
| Subtitle            | `font-sans`           | `text-subtitle`   | Regular |
| Body                | `font-sans`           | `text-body`       | Regular |
| Body bold           | `font-sans`           | `text-body`       | Bold   |
| Small               | `font-sans`           | `text-small`      | Regular/Bold |
| X-small             | `font-sans`           | `text-xsmall`     | Regular |

Responsive H1: `text-h1-sm md:text-h1-md lg:text-display`
Responsive H2: `text-h2-sm md:text-h2-md lg:text-h2`

## Breakpoints (Tailwind responsive prefixes)

| Prefix | Breakpoint |
|--------|------------|
| `sm:`  | 440px      |
| `md:`  | 834px  (tablet portrait) |
| `lg:`  | 1279px |
| `xl:`  | 1440px |
| `2xl:` | 1920px |

Note: Tailwind v4 uses `min-width` breakpoints. These are approximate — check
`node_modules/next/dist/docs/` for any Next.js 16 specifics before adjusting.

## Components (`components/ui/`)

| File          | Export      | Key props                                               |
|---------------|-------------|----------------------------------------------------------|
| Button.jsx    | `Button`    | `variant` primary/secondary/text, `size` sm/md/lg, `onDark`, `loading`, `disabled` |
| Chip.jsx      | `Chip`      | `variant` primary/secondary, `size` sm/md, `state` default/selected/applied, `iconLeft`, `iconRight`, `onDark` |
| Input.jsx     | `Input`     | `label`, `hint`, `error`, `iconLeft`, `iconRight`, `size` md/lg, `onDark` |
| Checkbox.jsx  | `Checkbox`  | `label`, `error`, `onDark`                              |

When building new components, follow this pattern:
1. Import `cn` from `@/lib/utils`
2. Use semantic color tokens (never raw hex or primitive vars)
3. Use named spacing tokens (never `p-4`, `p-8`, etc.)
4. Support `onDark` boolean when the component appears on dark surfaces
5. Forward unknown props with `...props` spread onto the root element

## Icons

The design system uses Material Symbols-style icons, named as:
`icon/category/icon_name` (e.g. `icon/search&filter/search`).

For implementation, use `@material-symbols/svg-400` package or inline SVG.
Icon color uses `text-icon-*` token (icons are styled as `currentColor`).
Standard icon size: 24×24px (`w-6 h-6`).

## Dos and don'ts

**Do:**
- Use `bg-surface-*`, `text-text-*`, `border-border-*` tokens
- Use `font-sans` and `font-display` for all text
- Use named spacing tokens for all padding/margin/gap
- Support dark mode through semantic tokens (not hardcoded dark: variants)

**Don't:**
- Use `text-black`, `bg-white`, `text-gray-*`, `bg-zinc-*` etc.
- Use arbitrary values like `p-[16px]` or `text-[16px]`
- Use Tailwind's numeric spacing scale (`p-4`, `m-8`)
- Import fonts outside of `app/layout.js`
