import { Noto_Sans } from "next/font/google";
// PP Formula Condensed is a paid font (by Production Type).
// To enable it, purchase the font, place the files in app/fonts/, then:
//   import localFont from "next/font/local";
//   const ppFormula = localFont({
//     variable: "--font-pp-formula",
//     src: [
//       { path: "./fonts/PPFormulaCondensed-Bold.woff2", weight: "700", style: "normal" },
//     ],
//   });
// Add ppFormula.variable to the html className below.
import "./globals.css";

const notoSans = Noto_Sans({
  variable: "--font-noto-sans",
  subsets: ["latin"],
  weight: ["400", "700"],
  style: ["normal", "italic"],
});

export const metadata = {
  title: "AI Search Assistant",
  description: "Alamy AI Search Assistant",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${notoSans.variable} h-full antialiased`}>
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
