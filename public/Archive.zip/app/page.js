import { getABVariant } from "@/lib/ab-testing";
import { SearchPageV1 } from "@/components/search/SearchPageV1";
import { SearchPageV2 } from "@/components/search/SearchPageV2";

export default async function Home() {
  const variant = await getABVariant();
  return variant === "v2" ? <SearchPageV2 /> : <SearchPageV1 />;
}
