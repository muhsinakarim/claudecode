"use client";

import { cn } from "@/lib/utils";

/**
 * Alamy Design System 2.0 — Button
 *
 * Props
 * ─────
 * variant   "primary" | "secondary" | "text"        default "primary"
 * size      "sm" | "md" | "lg"                       default "md"
 * onDark    boolean — render on dark surface          default false
 * disabled  boolean
 * loading   boolean — shows spinner, disables click
 * className additional Tailwind classes
 *
 * Usage
 * ─────
 * <Button>Buy now</Button>
 * <Button variant="secondary" size="sm">Cancel</Button>
 * <Button variant="primary" onDark loading>Saving…</Button>
 */

const base =
  "inline-flex items-center justify-center gap-2 rounded-full font-sans font-bold leading-none transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-brand";

const sizes = {
  sm: "h-8  px-xs  text-small",
  md: "h-10 px-sm  text-body",
  lg: "h-12 px-md  text-body",
};

const variants = {
  primary: {
    light:
      "bg-surface-brand text-text-primary hover:bg-[var(--green-400)] active:bg-[var(--green-500)]",
    dark:
      "bg-surface-brand text-text-primary hover:bg-[var(--green-400)] active:bg-[var(--green-500)]",
  },
  secondary: {
    light:
      "bg-transparent text-text-primary border border-border-primary hover:bg-surface-secondary active:bg-surface-tertiary",
    dark:
      "bg-transparent text-text-invert border border-border-invert hover:bg-surface-tertiary active:bg-surface-moderate",
  },
  text: {
    light:
      "bg-transparent text-text-primary underline-offset-2 hover:underline active:text-text-secondary",
    dark:
      "bg-transparent text-text-invert underline-offset-2 hover:underline active:text-text-moderate",
  },
};

const disabledClasses = "opacity-40 cursor-not-allowed pointer-events-none";

export function Button({
  variant = "primary",
  size = "md",
  onDark = false,
  disabled = false,
  loading = false,
  className,
  children,
  ...props
}) {
  const v = variants[variant] ?? variants.primary;
  const colorClasses = onDark ? v.dark : v.light;
  const isInactive = disabled || loading;

  return (
    <button
      disabled={isInactive}
      aria-busy={loading || undefined}
      className={cn(
        base,
        sizes[size],
        colorClasses,
        isInactive && disabledClasses,
        className
      )}
      {...props}
    >
      {loading && <Spinner />}
      {children}
    </button>
  );
}

function Spinner() {
  return (
    <span
      aria-hidden="true"
      className="block h-4 w-4 rounded-full border-2 border-current border-t-transparent animate-spin shrink-0"
    />
  );
}
