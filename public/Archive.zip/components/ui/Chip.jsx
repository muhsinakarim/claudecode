"use client";

import { cn } from "@/lib/utils";

/**
 * Alamy Design System 2.0 — Chip
 *
 * Props
 * ─────
 * variant   "primary" | "secondary"                  default "primary"
 * size      "sm" | "md"                               default "md"
 * state     "default" | "selected" | "applied"        default "default"
 * iconLeft  React node — icon rendered before label
 * iconRight React node — icon rendered after label
 * onDark    boolean                                   default false
 * disabled  boolean
 * onClick   function
 *
 * Usage
 * ─────
 * <Chip>Landscape</Chip>
 * <Chip variant="secondary" state="selected" iconLeft={<FilterIcon />}>
 *   Colour photos
 * </Chip>
 */

const base =
  "inline-flex items-center gap-1 rounded-full font-sans font-bold whitespace-nowrap transition-colors cursor-pointer select-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-brand";

const sizes = {
  sm: "h-7  px-xs  text-small",
  md: "h-8  px-sm  text-body",
};

function chipColor({ variant, state, onDark }) {
  if (variant === "primary") {
    if (state === "selected")
      return onDark
        ? "bg-surface-brand text-text-primary border border-border-brand"
        : "bg-surface-brand text-text-primary border border-border-brand";
    return onDark
      ? "bg-transparent text-text-invert border border-border-invert hover:bg-surface-tertiary"
      : "bg-transparent text-text-primary border border-border-primary hover:bg-surface-secondary";
  }

  // secondary
  if (state === "selected" || state === "applied")
    return onDark
      ? "bg-surface-brand text-text-primary border border-border-brand"
      : "bg-surface-brand text-text-primary border border-border-brand";

  return onDark
    ? "bg-transparent text-text-invert border border-border-tertiary hover:border-border-invert"
    : "bg-transparent text-text-primary border border-border-tertiary hover:border-border-primary";
}

export function Chip({
  variant = "primary",
  size = "md",
  state = "default",
  iconLeft,
  iconRight,
  onDark = false,
  disabled = false,
  className,
  children,
  onClick,
  ...props
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      aria-pressed={state === "selected" || state === "applied"}
      className={cn(
        base,
        sizes[size],
        chipColor({ variant, state, onDark }),
        disabled && "opacity-40 cursor-not-allowed pointer-events-none",
        className
      )}
      {...props}
    >
      {iconLeft && (
        <span className="shrink-0 text-[1em] leading-none" aria-hidden="true">
          {iconLeft}
        </span>
      )}
      {children}
      {iconRight && (
        <span className="shrink-0 text-[1em] leading-none" aria-hidden="true">
          {iconRight}
        </span>
      )}
    </button>
  );
}
