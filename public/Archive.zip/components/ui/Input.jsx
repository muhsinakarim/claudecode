"use client";

import { cn } from "@/lib/utils";

/**
 * Alamy Design System 2.0 — Input
 *
 * Props
 * ─────
 * label     string — visible label above the field
 * hint      string — helper text below the field
 * error     string — error message (sets error state)
 * iconLeft  React node
 * iconRight React node
 * onDark    boolean                                   default false
 * size      "md" | "lg"                               default "md"
 *
 * All native <input> props (type, placeholder, value, onChange…) pass through.
 *
 * Usage
 * ─────
 * <Input label="Search" placeholder="Find anything…" />
 * <Input label="Email" error="Enter a valid email" type="email" />
 */

const wrapperBase =
  "flex items-center gap-xs rounded-sm border bg-surface-primary font-sans text-text-primary transition-colors";

const sizes = {
  md: "h-10 px-sm text-body",
  lg: "h-12 px-sm text-body",
};

const states = {
  default:  "border-border-tertiary hover:border-border-secondary",
  focused:  "border-border-primary ring-1 ring-border-primary",
  error:    "border-border-red ring-1 ring-border-red",
  disabled: "border-border-tertiary bg-surface-secondary opacity-50 cursor-not-allowed",
};

export function Input({
  label,
  hint,
  error,
  iconLeft,
  iconRight,
  onDark = false,
  size = "md",
  disabled = false,
  className,
  id,
  ...props
}) {
  const inputId = id ?? (label ? label.toLowerCase().replace(/\s+/g, "-") : undefined);
  const state = disabled ? "disabled" : error ? "error" : "default";

  return (
    <div className="flex flex-col gap-xs w-full">
      {label && (
        <label
          htmlFor={inputId}
          className={cn(
            "font-sans text-small font-bold",
            onDark ? "text-text-invert" : "text-text-secondary"
          )}
        >
          {label}
        </label>
      )}

      <div
        className={cn(
          wrapperBase,
          sizes[size],
          states[state],
          onDark && "bg-surface-moderate border-border-invert",
          className
        )}
      >
        {iconLeft && (
          <span
            className={cn(
              "shrink-0 text-icon-secondary",
              onDark && "text-icon-invert"
            )}
            aria-hidden="true"
          >
            {iconLeft}
          </span>
        )}

        <input
          id={inputId}
          disabled={disabled}
          aria-invalid={error ? "true" : undefined}
          aria-describedby={
            error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined
          }
          className={cn(
            "flex-1 bg-transparent outline-none placeholder:text-text-moderate",
            "text-text-primary",
            onDark && "text-text-invert placeholder:text-text-moderate",
            disabled && "cursor-not-allowed"
          )}
          {...props}
        />

        {iconRight && (
          <span
            className={cn(
              "shrink-0 text-icon-secondary",
              onDark && "text-icon-invert"
            )}
            aria-hidden="true"
          >
            {iconRight}
          </span>
        )}
      </div>

      {error && (
        <p
          id={`${inputId}-error`}
          role="alert"
          className="font-sans text-xsmall text-text-red"
        >
          {error}
        </p>
      )}

      {!error && hint && (
        <p
          id={`${inputId}-hint`}
          className={cn(
            "font-sans text-xsmall",
            onDark ? "text-text-moderate" : "text-text-tertiary"
          )}
        >
          {hint}
        </p>
      )}
    </div>
  );
}
