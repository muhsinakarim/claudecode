"use client";

import { cn } from "@/lib/utils";

/**
 * Alamy Design System 2.0 — Checkbox
 *
 * Props
 * ─────
 * label    string — visible label text
 * error    boolean — error state
 * onDark   boolean                          default false
 * All native <input type="checkbox"> props pass through.
 *
 * Usage
 * ─────
 * <Checkbox label="Remember me" />
 * <Checkbox label="Accept terms" error />
 * <Checkbox label="Dark surface" onDark checked onChange={…} />
 */
export function Checkbox({
  label,
  error = false,
  onDark = false,
  disabled = false,
  className,
  id,
  ...props
}) {
  const inputId = id ?? (label ? `cb-${label.toLowerCase().replace(/\s+/g, "-")}` : undefined);

  return (
    <label
      htmlFor={inputId}
      className={cn(
        "inline-flex items-center gap-xs font-sans text-body cursor-pointer select-none",
        disabled && "opacity-40 cursor-not-allowed",
        onDark ? "text-text-invert" : "text-text-primary",
        className
      )}
    >
      <input
        type="checkbox"
        id={inputId}
        disabled={disabled}
        aria-invalid={error || undefined}
        className={cn(
          "h-4 w-4 shrink-0 appearance-none rounded-[2px] border transition-colors",
          "checked:bg-surface-brand checked:border-border-brand",
          "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-brand",
          error
            ? "border-border-red"
            : onDark
            ? "border-border-invert"
            : "border-border-primary",
          disabled && "cursor-not-allowed"
        )}
        style={{
          backgroundImage:
            "var(--tw-checked-bg, none)",
        }}
        {...props}
      />

      {/* Custom checkmark shown via sibling in accessible way */}
      <span className="relative -ml-[calc(1rem+var(--spacing-xs))] h-4 w-4 pointer-events-none">
        <CheckIcon />
      </span>

      {label && <span>{label}</span>}
    </label>
  );
}

function CheckIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 16 16"
      fill="none"
      className="absolute inset-0 opacity-0 peer-checked:opacity-100 text-text-primary"
      aria-hidden="true"
    >
      <path
        d="M3 8l3.5 3.5L13 4.5"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
