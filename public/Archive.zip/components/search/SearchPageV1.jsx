"use client";

import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

/* ─── Static data ────────────────────────────────────────────── */
const INIT_MESSAGES = [
  { id: 1, role: "ai", text: "I have found some beautiful images of different cats, young and old for you to choose from." },
  { id: 2, role: "user", text: "Thank you. I particularly want ginger/orange or grey/brown cats." },
  { id: 3, role: "ai", text: "That is not a problem. Is there any particular colour of bow you would like?" },
  { id: 4, role: "user", text: "Yellow or pink would be good. Though blue or white would work too." },
  { id: 5, role: "ai", text: "Excellent — this will give you a much broader selection to choose from." },
];

const TABS = [
  { id: "ai",         label: "AI Mode",           badge: "NEW" },
  { id: "all",        label: "All images" },
  { id: "creative",   label: "Creative images" },
  { id: "editorial",  label: "Editorial images" },
  { id: "smartphone", label: "Smartphone images" },
  { id: "videos",     label: "Videos" },
];

const SUGGESTIONS = ["cat and dog", "cat dog", "cat jumping", "cat sleeping", "cat food", "cat cafe"];

/* Placeholder image tiles — varying aspect ratios */
const GRID_ROWS = [
  [{ r: "4/3" }, { r: "3/4" }, { r: "4/3" }],
  [{ r: "4/3" }, { r: "3/4" }, { promo: true }, { r: "3/4" }],
  [{ r: "3/4" }, { r: "4/3" }, { r: "4/3" }],
  [{ r: "4/3" }, { r: "1/1" }, { r: "3/4" }, { r: "4/3" }, { r: "1/1" }],
];

/* ─── Sub-components ─────────────────────────────────────────── */

function AlamyLogo({ white = false }) {
  return (
    <span className={cn("font-sans font-bold text-[20px] tracking-tight leading-none", white ? "text-text-invert" : "text-text-primary")}>
      alamy
    </span>
  );
}

function NavHeader({ dark }) {
  return (
    <header className={cn("w-full border-b", dark ? "bg-surface-invert border-surface-moderate" : "bg-surface-primary border-border-tertiary")}>
      <div className="max-w-[1680px] mx-auto px-md flex items-center justify-between h-16 gap-md">
        {/* Logo */}
        <AlamyLogo white={dark} />

        {/* Primary nav */}
        <nav className="hidden lg:flex items-center gap-xs">
          {["Images", "Videos", "Creative", "Editorial", "Archive", "Blog", "Enterprise"].map((item) => (
            <button key={item} className={cn("px-xs py-xs text-small font-sans flex items-center gap-[2px] transition-colors", dark ? "text-text-invert hover:text-text-moderate" : "text-text-secondary hover:text-text-primary")}>
              {item}
              <ChevronDown size={12} dark={dark} />
            </button>
          ))}
        </nav>

        {/* Utility nav */}
        <div className="hidden lg:flex items-center gap-xs">
          {["About us", "Pricing"].map((item) => (
            <button key={item} className={cn("text-small font-sans transition-colors", dark ? "text-text-invert" : "text-text-secondary")}>
              {item}
            </button>
          ))}
          <button className={cn("text-small font-sans", dark ? "text-text-invert" : "text-text-secondary")}>
            Live chat
          </button>
          <button className={cn("text-small font-sans", dark ? "text-text-invert" : "text-text-secondary")}>
            ♡ Lightboxes
          </button>
          <button className={cn("text-small font-sans", dark ? "text-text-invert" : "text-text-secondary")}>
            🛒 Cart
          </button>
          <button className={cn("h-8 px-sm rounded-xs text-small font-bold font-sans transition-colors", dark ? "bg-surface-brand text-text-primary" : "bg-surface-invert text-text-invert hover:bg-surface-moderate")}>
            Sign in
          </button>
        </div>
      </div>
    </header>
  );
}

function SearchBar({ dark }) {
  return (
    <div className={cn("w-full border-b sticky top-0 z-20", dark ? "bg-surface-invert border-surface-moderate" : "bg-surface-primary border-border-tertiary")}>
      <div className="max-w-[1680px] mx-auto px-md py-xs flex gap-xs items-center h-[72px]">
        {/* Type dropdown */}
        <button className={cn("flex items-center gap-xs px-sm h-10 rounded-xs border text-small font-sans whitespace-nowrap transition-colors", dark ? "border-border-invert text-text-invert" : "border-border-tertiary text-text-secondary hover:border-border-secondary")}>
          <span className="text-[18px]">🖼</span>
          All images
          <ChevronDown size={12} dark={dark} />
        </button>

        {/* Search input */}
        <div className={cn("flex-1 flex items-center gap-xs h-10 px-sm rounded-xs border transition-colors", dark ? "border-border-invert bg-surface-moderate" : "border-border-primary bg-surface-primary")}>
          <input
            defaultValue="Cat"
            className={cn("flex-1 bg-transparent outline-none text-body font-sans", dark ? "text-text-invert placeholder:text-text-moderate" : "text-text-primary")}
          />
          <button className={cn("text-icon-secondary text-small", dark && "text-text-moderate")}>✕</button>
        </div>

        {/* Search by image */}
        <button className={cn("flex items-center gap-xs px-sm h-10 rounded-xs border text-small font-sans whitespace-nowrap transition-colors", dark ? "border-border-invert text-text-invert" : "border-border-tertiary text-text-secondary hover:border-border-secondary")}>
          <span>📷</span>
          Search by image
        </button>
      </div>
    </div>
  );
}

function ContentTabs({ activeTab, onTabChange, dark }) {
  return (
    <div className={cn("w-full border-b sticky top-[72px] z-10", dark ? "bg-surface-invert border-surface-moderate" : "bg-surface-primary border-border-tertiary")}>
      <div className="max-w-[1680px] mx-auto px-md flex items-end gap-none overflow-x-auto">
        {TABS.map((tab) => {
          const isActive = tab.id === activeTab;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={cn(
                "flex items-center gap-xs px-sm py-sm text-small font-sans whitespace-nowrap border-b-2 transition-colors",
                isActive
                  ? "border-surface-brand text-text-brand font-bold"
                  : dark
                  ? "border-transparent text-text-invert hover:text-text-moderate"
                  : "border-transparent text-text-secondary hover:text-text-primary"
              )}
            >
              {tab.label}
              {tab.badge && (
                <span className="bg-surface-brand text-text-primary text-[10px] font-bold px-[4px] py-[1px] rounded-xs leading-none">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function FilterBar() {
  return (
    <div className="w-full border-b border-border-tertiary bg-surface-primary">
      <div className="max-w-[1680px] mx-auto px-md py-xs flex items-center justify-between h-14">
        <button className="flex items-center gap-xs px-sm h-9 rounded-xs border border-border-tertiary text-small font-sans hover:border-border-secondary transition-colors">
          ⚙ Filters
        </button>
        <div className="flex items-center gap-xs text-small font-sans text-text-secondary">
          Sort by:
          <button className="flex items-center gap-[4px] font-bold text-text-primary">
            Newest <ChevronDown size={12} />
          </button>
        </div>
      </div>
    </div>
  );
}

function ResultsHeader() {
  return (
    <div className="mb-md">
      <div className="flex items-center gap-sm mb-xs flex-wrap">
        <h1 className="font-sans text-h4 font-bold text-text-primary">
          Cat Stock Photos and Images (1,087,456)
        </h1>
        <button className="text-small text-text-blue-bold underline font-sans">
          See cat stock video clips
        </button>
      </div>
      <div className="flex items-center gap-xs flex-wrap">
        {SUGGESTIONS.map((s) => (
          <button key={s} className="flex items-center gap-xs px-xs py-[4px] rounded-xs border border-border-tertiary text-small font-sans text-text-secondary hover:border-border-secondary transition-colors">
            🔍 {s}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-xs text-small font-sans text-text-secondary">
          Page <input defaultValue="1" className="w-10 text-center border border-border-tertiary rounded-xs px-xs outline-none text-small" /> of 100
        </div>
      </div>
    </div>
  );
}

function PromoCard() {
  return (
    <div className="w-full bg-surface-invert rounded-xs p-md flex flex-col items-center justify-center gap-md text-center min-h-[180px]">
      <AlamyLogo white />
      <p className="font-display text-h4 text-text-invert font-bold uppercase leading-tight tracking-wide">
        WE HAVE MULTIPLE LICENCE TYPES TO SUIT YOUR NEED
      </p>
      <button className="bg-surface-brand text-text-primary text-small font-bold font-sans px-md py-xs rounded-xs hover:bg-[var(--green-400)] transition-colors">
        Learn more
      </button>
    </div>
  );
}

function ImageGrid() {
  return (
    <div className="flex flex-col gap-sm mb-xl">
      {GRID_ROWS.map((row, ri) => (
        <div key={ri} className="flex gap-sm items-stretch">
          {row.map((cell, ci) =>
            cell.promo ? (
              <div key={ci} className="flex-1">
                <PromoCard />
              </div>
            ) : (
              <div
                key={ci}
                className="flex-1 bg-neutral-200 rounded-xs overflow-hidden hover:opacity-90 cursor-pointer transition-opacity"
                style={{ aspectRatio: cell.r }}
              />
            )
          )}
        </div>
      ))}
      <div className="flex justify-center pt-md">
        <button className="px-2xl py-xs rounded-xs border border-border-primary text-small font-bold font-sans hover:bg-surface-secondary transition-colors">
          Next page
        </button>
      </div>
    </div>
  );
}

function AIChatPanel({ messages, input, onInput, onSend }) {
  const bottomRef = useRef(null);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  return (
    <div className="w-[564px] shrink-0 flex flex-col bg-surface-invert border-r border-surface-moderate h-[calc(100vh-145px)] sticky top-[145px]">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-md flex flex-col gap-md">
        {messages.map((msg) => (
          <div key={msg.id} className={cn("flex gap-sm items-start", msg.role === "user" && "flex-row-reverse")}>
            {msg.role === "ai" && (
              <div className="shrink-0 w-7 h-7 rounded-full bg-surface-brand flex items-center justify-center text-text-primary font-bold text-small font-sans">
                A
              </div>
            )}
            <div className={cn("max-w-[80%] px-sm py-xs rounded-sm text-small font-sans leading-relaxed",
              msg.role === "ai" ? "bg-surface-moderate text-text-invert" : "bg-surface-bold text-text-invert"
            )}>
              {msg.text}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Suggested prompts */}
      <div className="px-md pb-xs flex gap-sm">
        {["+ Suggested prompts", "+ Suggested prompts"].map((s, i) => (
          <button key={i} className="flex-1 px-sm py-xs rounded-xs border border-surface-moderate text-small font-sans text-text-invert text-left hover:bg-surface-moderate transition-colors">
            {s}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="px-md pb-md">
        <div className="relative border border-surface-moderate rounded-sm bg-surface-moderate">
          <textarea
            value={input}
            onChange={(e) => onInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); onSend(); } }}
            placeholder="Ask me anything...."
            rows={3}
            className="w-full bg-transparent text-text-invert placeholder:text-text-moderate text-small font-sans p-sm pr-2xl resize-none outline-none"
          />
          <div className="absolute right-sm bottom-sm flex flex-col gap-xs">
            <button className="text-icon-secondary hover:text-icon-invert transition-colors">🎙</button>
          </div>
        </div>
        <div className="flex justify-between items-center mt-xs">
          <button className="text-icon-secondary hover:text-icon-invert text-small transition-colors">📎</button>
          <button
            onClick={onSend}
            className="w-8 h-8 rounded-full bg-surface-brand flex items-center justify-center text-text-primary hover:bg-[var(--green-400)] transition-colors"
          >
            ↑
          </button>
        </div>
      </div>
    </div>
  );
}

function ChevronDown({ size = 16, dark = false }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" className={dark ? "text-text-invert" : "text-text-secondary"}>
      <path d="M4 6l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ─── Main export ────────────────────────────────────────────── */
export function SearchPageV1() {
  const [activeTab, setActiveTab] = useState("all");
  const [messages, setMessages] = useState(INIT_MESSAGES);
  const [input, setInput] = useState("");
  const aiMode = activeTab === "ai";

  function handleSend() {
    const text = input.trim();
    if (!text) return;
    setMessages((prev) => [...prev, { id: Date.now(), role: "user", text }]);
    setInput("");
    // Simulated AI reply
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        { id: Date.now() + 1, role: "ai", text: "I have updated the search results based on your request. Let me know if you'd like to refine further." },
      ]);
    }, 800);
  }

  return (
    <div className="min-h-screen bg-surface-primary">
      {/* Header */}
      <NavHeader dark={aiMode} />

      {/* Sticky search bar */}
      <SearchBar dark={aiMode} />

      {/* Content-type tabs */}
      <ContentTabs activeTab={activeTab} onTabChange={setActiveTab} dark={aiMode} />

      {/* Filter bar — only in standard mode */}
      {!aiMode && <FilterBar />}

      {/* Main content */}
      <div className={cn("max-w-[1680px] mx-auto", aiMode ? "flex" : "")}>
        {aiMode && (
          <AIChatPanel messages={messages} input={input} onInput={setInput} onSend={handleSend} />
        )}
        <div className={cn("flex-1 min-w-0", aiMode ? "px-md pt-md" : "px-md pt-md")}>
          <ResultsHeader />
          <ImageGrid />
        </div>
      </div>
    </div>
  );
}
