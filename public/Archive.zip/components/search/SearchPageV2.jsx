"use client";

import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

/* ─── Static data ────────────────────────────────────────────── */
const INIT_MESSAGES = [
  { id: 1, role: "ai", text: "I have found some beautiful images of different cats, young and old for you to choose from." },
  { id: 2, role: "user", text: "Thank you. I particularly want ginger/orange or grey/brown cats." },
  { id: 3, role: "ai", text: "That is not a problem. Is there any particular colour of bow you would like?" },
  { id: 4, role: "user", text: "Yellow or pink would be good. Though blue or white would work too." },
  { id: 5, role: "ai", text: "I have updated the selection. Would you like aerial shots?" },
  { id: 6, role: "user", text: "Please provide me with shots from all angles." },
  { id: 7, role: "ai", text: "Excellent — this will give you a much broader selection to choose from." },
];

const BROWSE_COLLECTIONS = ["All", "Creative Images", "Editorial Images", "Smartphone Images", "Videos"];

const FILTER_SECTIONS = [
  "Licences", "Releases", "Date taken",
  "Orientation", "Image type", "Colour",
  "Age", "Agencies", "Search builder",
];

const SUGGESTIONS = ["cat and dog", "cat dog", "cat jumping", "cat sleeping", "cat food", "cat cafe"];

const GRID_ROWS = [
  [{ r: "4/3" }, { r: "3/4" }, { r: "4/3" }],
  [{ r: "4/3" }, { r: "3/4" }, { promo: true }, { r: "3/4" }],
  [{ r: "3/4" }, { r: "4/3" }, { r: "4/3" }],
  [{ r: "4/3" }, { r: "1/1" }, { r: "3/4" }, { r: "4/3" }, { r: "1/1" }],
];

/* ─── Sub-components ─────────────────────────────────────────── */

function AlamyLogo() {
  return (
    <span className="font-sans font-bold text-[20px] tracking-tight leading-none text-text-primary">
      alamy
    </span>
  );
}

function NavHeader() {
  return (
    <header className="w-full border-b border-border-tertiary bg-surface-primary">
      <div className="max-w-[1680px] mx-auto px-md flex items-center justify-between h-16 gap-md">
        <AlamyLogo />
        <nav className="hidden lg:flex items-center gap-xs">
          {["Images", "Videos", "Creative", "Editorial", "Archive", "Blog", "Enterprise"].map((item) => (
            <button key={item} className="px-xs py-xs text-small font-sans flex items-center gap-[2px] text-text-secondary hover:text-text-primary transition-colors">
              {item}
              <ChevronDown size={12} />
            </button>
          ))}
        </nav>
        <div className="hidden lg:flex items-center gap-xs">
          {["About us", "Pricing"].map((item) => (
            <button key={item} className="text-small font-sans text-text-secondary">{item}</button>
          ))}
          <button className="text-small font-sans text-text-secondary">Live chat</button>
          <button className="text-small font-sans text-text-secondary">♡ Lightboxes</button>
          <button className="text-small font-sans text-text-secondary">🛒 Cart</button>
          <button className="h-8 px-sm rounded-xs bg-surface-invert text-text-invert text-small font-bold font-sans hover:bg-surface-moderate transition-colors">
            Sign in
          </button>
        </div>
      </div>
    </header>
  );
}

function SearchBar({ aiActive, onToggleAI }) {
  return (
    <div className="w-full border-b border-border-tertiary bg-surface-primary sticky top-0 z-20">
      <div className="max-w-[1680px] mx-auto px-md flex gap-xs items-center h-[56px]">
        <button className="flex items-center gap-xs px-sm h-9 rounded-xs border border-border-tertiary text-small font-sans whitespace-nowrap hover:border-border-secondary transition-colors">
          <span>🖼</span>All images<ChevronDown size={12} />
        </button>
        <div className="flex-1 flex items-center gap-xs h-9 px-sm rounded-xs border border-border-primary bg-surface-primary">
          <input defaultValue="Cat" className="flex-1 bg-transparent outline-none text-body font-sans text-text-primary" />
          <button className="text-icon-secondary text-small">✕</button>
        </div>
        <button className="flex items-center gap-xs px-sm h-9 rounded-xs border border-border-tertiary text-small font-sans whitespace-nowrap hover:border-border-secondary transition-colors">
          <span>📷</span>Search by image
        </button>
      </div>

      {/* AI Search & Filters toggle strip */}
      <div
        className="max-w-[1680px] mx-auto px-md flex items-center gap-xs h-9 border-t border-border-tertiary cursor-pointer hover:bg-surface-secondary transition-colors"
        onClick={onToggleAI}
      >
        <div className={cn("w-8 h-4 rounded-full flex items-center px-[2px] transition-colors", aiActive ? "bg-surface-brand" : "bg-neutral-300")}>
          <div className={cn("w-3 h-3 rounded-full bg-surface-primary shadow transition-transform", aiActive && "translate-x-4")} />
        </div>
        <span className="text-small font-bold font-sans text-text-brand">AI Search &amp; Filters</span>
        {!aiActive && <ChevronDown size={12} />}
      </div>
    </div>
  );
}

function CollapsedRail({ onExpand }) {
  return (
    <aside className="shrink-0 w-8 flex flex-col items-center pt-md border-r border-border-tertiary bg-surface-primary">
      <button
        onClick={onExpand}
        className="flex flex-col items-center gap-xs text-text-secondary hover:text-text-primary transition-colors"
        title="Expand AI Search & Filters"
      >
        <span className="text-[18px] rotate-[-90deg]">▶</span>
        <span className="text-[9px] font-bold font-sans text-text-brand rotate-180 tracking-wide" style={{ writingMode: "vertical-rl" }}>
          NEW
        </span>
        <span className="text-[9px] font-sans text-text-secondary rotate-180" style={{ writingMode: "vertical-rl" }}>
          AI Search &amp; Filters
        </span>
      </button>
    </aside>
  );
}

function ClassicSearchPanel() {
  const [openFilters, setOpenFilters] = useState(["Licences"]);
  function toggle(name) {
    setOpenFilters((prev) => prev.includes(name) ? prev.filter((f) => f !== name) : [...prev, name]);
  }
  return (
    <div className="overflow-y-auto h-full">
      {/* Browse Collections */}
      <div className="px-md pt-md pb-sm border-b border-border-tertiary">
        <p className="text-small font-bold font-sans text-text-secondary mb-xs uppercase tracking-wide">Browse Collections</p>
        {BROWSE_COLLECTIONS.map((col) => (
          <button key={col} className="flex items-center justify-between w-full py-xs text-small font-sans text-text-primary hover:text-text-brand transition-colors">
            {col}
            <ChevronDown size={12} />
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="px-md pt-sm">
        <div className="flex items-center justify-between mb-xs">
          <p className="text-small font-bold font-sans text-text-secondary uppercase tracking-wide">Filters</p>
          <ChevronUp size={12} />
        </div>
        {FILTER_SECTIONS.map((name) => (
          <div key={name} className="border-b border-border-tertiary last:border-0">
            <button
              onClick={() => toggle(name)}
              className="flex items-center justify-between w-full py-sm text-small font-sans text-text-primary hover:text-text-brand transition-colors"
            >
              {name}
              {openFilters.includes(name) ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
            </button>
            {openFilters.includes(name) && (
              <div className="pb-sm pl-sm text-xsmall font-sans text-text-tertiary">
                No options available for this prototype.
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function AIChatPanel({ messages, input, onInput, onSend, onClear }) {
  const bottomRef = useRef(null);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-md py-sm flex flex-col gap-sm">
        {messages.map((msg) => (
          <div key={msg.id} className={cn("flex gap-xs items-start", msg.role === "user" && "flex-row-reverse")}>
            {msg.role === "ai" && (
              <div className="shrink-0 w-6 h-6 rounded-full bg-surface-brand flex items-center justify-center text-text-primary font-bold text-xsmall font-sans">
                A
              </div>
            )}
            <div className={cn("max-w-[85%] px-sm py-xs rounded-sm text-small font-sans leading-relaxed",
              msg.role === "ai"
                ? "bg-surface-brand-minimal text-text-primary border border-border-brand"
                : "bg-surface-secondary text-text-primary border border-border-tertiary"
            )}>
              {msg.text}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="px-md pb-md pt-xs border-t border-border-tertiary">
        <textarea
          value={input}
          onChange={(e) => onInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); onSend(); } }}
          placeholder="Describe what you're looking for..."
          rows={3}
          className="w-full border border-border-tertiary rounded-xs bg-surface-primary text-text-primary placeholder:text-text-moderate text-small font-sans p-sm resize-none outline-none focus:border-border-primary transition-colors"
        />
        <div className="flex gap-xs mt-xs">
          <button
            onClick={onSend}
            className="flex-1 h-9 rounded-xs bg-surface-brand text-text-primary text-small font-bold font-sans hover:bg-[var(--green-400)] transition-colors"
          >
            Search
          </button>
          <button
            onClick={onClear}
            className="px-md h-9 rounded-xs border border-border-tertiary text-small font-sans text-text-secondary hover:border-border-primary transition-colors"
          >
            Clear
          </button>
        </div>
      </div>
    </div>
  );
}

function SearchSidebar({ sidebarTab, onTabChange, onCollapse, messages, input, onInput, onSend, onClear }) {
  return (
    <aside className="w-[413px] shrink-0 flex flex-col border-r border-border-tertiary bg-surface-primary h-[calc(100vh-105px)] sticky top-[105px]">
      {/* Tab bar */}
      <div className="flex items-stretch border-b border-border-tertiary shrink-0">
        <button
          onClick={() => onTabChange("classic")}
          className={cn("flex-1 flex items-center justify-center gap-xs py-sm text-small font-sans transition-colors border-b-2",
            sidebarTab === "classic" ? "border-border-primary text-text-primary font-bold" : "border-transparent text-text-secondary hover:text-text-primary"
          )}
        >
          🔍 Classic Search
        </button>
        <button
          onClick={() => onTabChange("ai")}
          className={cn("flex-1 flex items-center justify-center gap-xs py-sm text-small font-sans transition-colors border-b-2",
            sidebarTab === "ai" ? "border-surface-brand text-text-brand font-bold" : "border-transparent text-text-secondary hover:text-text-primary"
          )}
        >
          ✦ AI Search
          <span className="bg-surface-brand text-text-primary text-[10px] font-bold px-[4px] py-[1px] rounded-xs leading-none">NEW</span>
        </button>
        <button
          onClick={onCollapse}
          className="px-sm py-sm text-icon-secondary hover:text-icon-primary transition-colors border-b-2 border-transparent"
          title="Collapse sidebar"
        >
          ◀
        </button>
      </div>

      {/* Panel content */}
      <div className="flex-1 overflow-hidden">
        {sidebarTab === "classic" ? (
          <ClassicSearchPanel />
        ) : (
          <AIChatPanel messages={messages} input={input} onInput={onInput} onSend={onSend} onClear={onClear} />
        )}
      </div>
    </aside>
  );
}

function AIBanner({ query }) {
  return (
    <div className="flex items-center gap-xs px-md py-xs bg-surface-brand-minimal border-b border-border-brand text-small font-sans text-text-primary">
      <span className="bg-surface-brand text-text-primary text-[10px] font-bold px-xs py-[1px] rounded-xs">AI</span>
      <span>Results refined by AI Smart Search · {query}</span>
    </div>
  );
}

function ResultsHeader({ narrow }) {
  return (
    <div className="mb-md">
      <div className="flex items-center gap-sm mb-xs flex-wrap">
        <h1 className="font-sans text-h4 font-bold text-text-primary">
          Cat Stock Photos and Images (1,087,456)
        </h1>
        <button className="text-small text-text-blue-bold underline font-sans">
          See cat stock video clips
        </button>
      </div>
      <div className="flex items-center gap-xs flex-wrap">
        {SUGGESTIONS.map((s) => (
          <button key={s} className="flex items-center gap-xs px-xs py-[4px] rounded-xs border border-border-tertiary text-small font-sans text-text-secondary hover:border-border-secondary transition-colors">
            🔍 {s}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-xs text-small font-sans text-text-secondary">
          Sort by:
          <button className="font-bold text-text-primary flex items-center gap-[4px]">Newest <ChevronDown size={12} /></button>
          <span className="mx-xs">|</span>
          Page <input defaultValue="1" className="w-10 text-center border border-border-tertiary rounded-xs px-xs outline-none text-small" /> of 100
        </div>
      </div>
    </div>
  );
}

function PromoCard() {
  return (
    <div className="w-full bg-surface-invert rounded-xs p-md flex flex-col items-center justify-center gap-md text-center min-h-[180px]">
      <span className="font-sans font-bold text-[20px] tracking-tight leading-none text-text-invert">alamy</span>
      <p className="font-display text-h4 text-text-invert font-bold uppercase leading-tight tracking-wide">
        WE HAVE MULTIPLE LICENCE TYPES TO SUIT YOUR NEED
      </p>
      <button className="bg-surface-brand text-text-primary text-small font-bold font-sans px-md py-xs rounded-xs hover:bg-[var(--green-400)] transition-colors">
        Learn more
      </button>
    </div>
  );
}

function ImageGrid() {
  return (
    <div className="flex flex-col gap-sm mb-xl">
      {GRID_ROWS.map((row, ri) => (
        <div key={ri} className="flex gap-sm items-stretch">
          {row.map((cell, ci) =>
            cell.promo ? (
              <div key={ci} className="flex-1"><PromoCard /></div>
            ) : (
              <div key={ci} className="flex-1 bg-neutral-200 rounded-xs overflow-hidden hover:opacity-90 cursor-pointer transition-opacity" style={{ aspectRatio: cell.r }} />
            )
          )}
        </div>
      ))}
      <div className="flex justify-center pt-md">
        <button className="px-2xl py-xs rounded-xs border border-border-primary text-small font-bold font-sans hover:bg-surface-secondary transition-colors">
          Next page
        </button>
      </div>
    </div>
  );
}

function ChevronDown({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" className="text-text-secondary shrink-0">
      <path d="M4 6l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function ChevronUp({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" className="text-text-secondary shrink-0">
      <path d="M4 10l4-4 4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ─── Main export ────────────────────────────────────────────── */
export function SearchPageV2() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarTab, setSidebarTab] = useState("classic");
  const [aiActive, setAiActive] = useState(false);
  const [aiQuery, setAiQuery] = useState("Showing ginger & grey cats · All angles");
  const [messages, setMessages] = useState(INIT_MESSAGES);
  const [input, setInput] = useState("");

  function handleToggleAI() {
    if (!sidebarOpen) {
      setSidebarOpen(true);
      setSidebarTab("ai");
    } else if (sidebarTab !== "ai") {
      setSidebarTab("ai");
    } else {
      setSidebarOpen(false);
    }
  }

  function handleSend() {
    const text = input.trim();
    if (!text) return;
    setMessages((prev) => [...prev, { id: Date.now(), role: "user", text }]);
    setInput("");
    setAiActive(true);
    setAiQuery(`Showing results for: "${text}"`);
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        { id: Date.now() + 1, role: "ai", text: "I have updated the search results based on your request. Let me know if you'd like to refine further." },
      ]);
    }, 800);
  }

  function handleClear() {
    setMessages(INIT_MESSAGES);
    setInput("");
    setAiActive(false);
  }

  return (
    <div className="min-h-screen bg-surface-primary">
      <NavHeader />
      <SearchBar aiActive={sidebarOpen && sidebarTab === "ai"} onToggleAI={handleToggleAI} />

      <div className="flex">
        {/* Sidebar / collapsed rail */}
        {sidebarOpen ? (
          <SearchSidebar
            sidebarTab={sidebarTab}
            onTabChange={setSidebarTab}
            onCollapse={() => setSidebarOpen(false)}
            messages={messages}
            input={input}
            onInput={setInput}
            onSend={handleSend}
            onClear={handleClear}
          />
        ) : (
          <CollapsedRail onExpand={() => setSidebarOpen(true)} />
        )}

        {/* Results area */}
        <div className="flex-1 min-w-0">
          {aiActive && sidebarTab === "ai" && <AIBanner query={aiQuery} />}
          <div className="px-md pt-md">
            <ResultsHeader narrow={sidebarOpen} />
            <ImageGrid />
          </div>
        </div>
      </div>
    </div>
  );
}
