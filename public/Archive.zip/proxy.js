import { NextResponse } from "next/server";

/**
 * AB test variant assignment.
 * Assigns 'v1' or 'v2' (50/50) on first visit and stores it in a 30-day
 * cookie. Subsequent requests pass straight through.
 */
export function proxy(request) {
  if (request.cookies.get("ab_variant")?.value) {
    return NextResponse.next();
  }

  const variant = Math.random() < 0.5 ? "v1" : "v2";
  const response = NextResponse.next();
  response.cookies.set("ab_variant", variant, {
    maxAge: 60 * 60 * 24 * 30, // 30 days
    path: "/",
    sameSite: "lax",
    httpOnly: true,
  });
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
